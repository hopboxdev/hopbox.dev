#!/usr/bin/env bash
# backup.sh — verified, off-host backups of hopboxd's irreplaceable state, and the
# restore path back. Installed by provision.sh as /usr/local/bin/hopbox-backup and
# run daily by hopbox-backup.timer.
#
#   hopbox-backup run                      snapshot + verify + ship + prune (the timer)
#   hopbox-backup list                     what is on the destination
#   hopbox-backup verify [latest|ARCHIVE]  fetch an archive and prove it restores
#   hopbox-backup restore [latest|ARCHIVE] [--into DIR] [--apply]
#
# What it backs up: the SQLite control-plane DBs (boxes, accounts, shares) and the
# SSH host key — the front door's identity, which cannot be recreated. The DBs are
# snapshotted with SQLite `VACUUM INTO` (an online, consistent copy — never a file
# copy of a live DB) and every snapshot must pass `PRAGMA integrity_check` before
# the archive counts as a backup.
#
# What it does NOT back up: the shared workspace /wrk (MinIO bucket + its JuiceFS
# metadata), box disks, and persistent homes. /wrk is scratch, not durable storage
# — see docs/guide/backups.md.
#
# Config: /etc/hopbox/backup.env (see deploy/backup.example.env). The off-host
# destination (HOPBOX_BACKUP_DEST) has no default: unconfigured, this exits with a
# clear error (78) rather than pretending to have backed anything up.
set -euo pipefail

CONF_FILE="${HOPBOX_BACKUP_ENV:-/etc/hopbox/backup.env}"
# shellcheck source=/dev/null
[ -f "$CONF_FILE" ] && . "$CONF_FILE"

DEST="${HOPBOX_BACKUP_DEST:-}"
NAME="${HOPBOX_BACKUP_NAME:-$(hostname -s 2>/dev/null || hostname)}"
LOCAL_DIR="${HOPBOX_BACKUP_LOCAL_DIR:-/var/backups/hopbox}"
KEEP_DAYS="${HOPBOX_BACKUP_KEEP_DAYS:-30}"
KEEP_MIN="${HOPBOX_BACKUP_KEEP_MIN:-7}"
KEEP_LOCAL="${HOPBOX_BACKUP_KEEP_LOCAL:-3}"
HOPBOXD_CONFIG="${HOPBOX_BACKUP_CONFIG:-/etc/hopbox/hopboxd.yaml}"
HOPBOXD_ENV="${HOPBOX_BACKUP_ENVFILE:-/etc/hopbox/hopboxd.env}"
INCLUDE_CONFIG="${HOPBOX_BACKUP_INCLUDE_CONFIG:-true}"
SERVICE="${HOPBOX_BACKUP_SERVICE-hopboxd}"
RCLONE_CONF="${HOPBOX_BACKUP_RCLONE_CONFIG:-}"
PREFIX_NAME="hopbox-backup-$NAME-"
DOC_URL="https://hopbox.dev/guide/backups"

umask 077

log()  { printf '\033[1;35m==>\033[0m %s\n' "$*"; }
warn() { printf '\033[1;33mwarn:\033[0m %s\n' "$*" >&2; }
die()  { printf '\033[1;31merror:\033[0m %s\n' "$*" >&2; exit 1; }
# unconfigured is its own exit code (EX_CONFIG) so the timer fails loudly and an
# operator can tell "not set up yet" from "the backup broke".
die_conf() { printf '\033[1;31merror:\033[0m %s\n' "$*" >&2; exit 78; }

need() { command -v "$1" >/dev/null 2>&1 || die "$1 is required but not installed${2:+ ($2)}"; }

# ---------- portable helpers (Linux hosts; also runnable on a dev Mac) ----------

sha256_of() {
  if command -v sha256sum >/dev/null 2>&1; then sha256sum "$1" | awk '{print $1}'
  else shasum -a 256 "$1" | awk '{print $1}'; fi
}
size_of() { wc -c <"$1" | tr -d ' '; }
stamp_now() { date -u +%Y%m%dT%H%M%SZ; }
# stamp N days ago, GNU date or BSD date
stamp_days_ago() {
  date -u -d "-$1 days" +%Y%m%dT%H%M%SZ 2>/dev/null || date -u -v-"$1"d +%Y%m%dT%H%M%SZ
}
# the timestamp embedded in an archive name, or empty
stamp_of() {
  local n=${1##*/}; n=${n#"$PREFIX_NAME"}; n=${n%.tar.gz}
  case "$n" in [0-9][0-9][0-9][0-9][0-9][0-9][0-9][0-9]T[0-9][0-9][0-9][0-9][0-9][0-9]Z) echo "$n" ;; *) echo "" ;; esac
}

# ---------- where the live state is ----------

yaml_get() { # key file → value (unquoted, comment-stripped)
  [ -f "$2" ] || return 0
  sed -n "s/^[[:space:]]*$1:[[:space:]]*//p" "$2" | head -1 |
    sed -e 's/[[:space:]]*#.*$//' -e 's/^"\(.*\)"$/\1/' -e "s/^'\(.*\)'\$/\1/" -e 's/[[:space:]]*$//'
}
env_get() { # KEY file → value
  [ -f "$2" ] || return 0
  sed -n "s/^[[:space:]]*$1=//p" "$2" | head -1 | tr -d '"' | sed -e 's/[[:space:]]*$//'
}

DB="${HOPBOX_BACKUP_DB:-}"
[ -n "$DB" ] || DB=$(yaml_get db "$HOPBOXD_CONFIG")
[ -n "$DB" ] || DB=$(env_get HOPBOX_DB "$HOPBOXD_ENV")
[ -n "$DB" ] || DB=/var/lib/hopbox/hopboxd.db

HOST_KEY="${HOPBOX_BACKUP_HOST_KEY:-}"
[ -n "$HOST_KEY" ] || HOST_KEY=$(yaml_get host-key "$HOPBOXD_CONFIG")
[ -n "$HOST_KEY" ] || HOST_KEY=$(env_get HOPBOX_HOST_KEY "$HOPBOXD_ENV")
[ -n "$HOST_KEY" ] || HOST_KEY=/var/lib/hopbox/hopboxd-ssh-host-key

# hopboxd derives these from --db (cmd/hopboxd/main.go); mirror it exactly.
DB_BASE="${DB%.db}"
ACCOUNTS_DB="$DB_BASE-accounts.db"
SHARES_DB="$DB_BASE-shares.db"

# ---------- destination: an rclone remote, or a filesystem path ----------

dest_is_remote() { # "remote:path" is rclone; "/mnt/x" or "./x" is a filesystem path
  case "$DEST" in
    ""|/*|./*|../*) return 1 ;;
    *:*) case "${DEST%%:*}" in */*) return 1 ;; *) return 0 ;; esac ;;  # a / before the : ⇒ a path
    *) return 1 ;;
  esac
}
rc() { # rclone with the configured config file
  if [ -n "$RCLONE_CONF" ]; then rclone --config "$RCLONE_CONF" "$@"; else rclone "$@"; fi
}
dest_require() {
  [ -n "$DEST" ] || die_conf "no backup destination configured.
  Set HOPBOX_BACKUP_DEST in $CONF_FILE to an rclone remote (e.g. 's3backup:hopbox/ks')
  or a path on off-host storage, then: systemctl start hopbox-backup.service
  Until then nothing is being backed up. See $DOC_URL"
  if dest_is_remote; then
    need rclone "the off-host destination is an rclone remote"
    rc lsd "${DEST%%:*}:" >/dev/null 2>&1 || die "rclone remote '${DEST%%:*}' is not usable — check 'rclone config' (config: ${RCLONE_CONF:-default})"
  else
    mkdir -p "$DEST" || die "cannot create destination directory $DEST"
  fi
}
dest_put() { # file → destination (0600 for a filesystem destination)
  if dest_is_remote; then rc copyto "$1" "$DEST/${1##*/}"
  else install -m600 "$1" "$DEST/${1##*/}"; fi
}
dest_get() { # name outfile
  if dest_is_remote; then rc copyto "$DEST/$1" "$2"
  else cp "$DEST/$1" "$2"; fi
}
dest_rm() { # name (best effort)
  if dest_is_remote; then rc deletefile "$DEST/$1" >/dev/null 2>&1 || true
  else rm -f "${DEST:?}/$1"; fi
}
list_dir_archives() { # dir → archive names, oldest → newest (names sort chronologically)
  local f
  for f in "$1/$PREFIX_NAME"*.tar.gz; do
    [ -f "$f" ] || continue      # an unmatched glob is "none", not a failure (pipefail)
    echo "${f##*/}"
  done | sort
}
dest_list() { # archive names, oldest → newest
  if dest_is_remote; then rc lsf "$DEST" 2>/dev/null | grep "^${PREFIX_NAME}.*\.tar\.gz$" | sort || true
  else list_dir_archives "$DEST"; fi
}
dest_describe() {
  if dest_is_remote; then echo "rclone remote $DEST"; else echo "path $DEST"; fi
}
# Loud about the classic mistake: a "backup" that dies with the host.
dest_offhost_check() {
  if dest_is_remote; then
    local shown
    shown=$(rc config show "${DEST%%:*}" 2>/dev/null || true)
    case "$shown" in
      *127.0.0.1*|*localhost*|*"::1"*)
        warn "destination remote '${DEST%%:*}' points at this host — that is not a backup. Use off-host storage." ;;
    esac
  else
    local a b
    a=$(df -P "$DEST" 2>/dev/null | awk 'NR==2{print $1}')
    b=$(df -P "$(dirname "$DB")" 2>/dev/null | awk 'NR==2{print $1}')
    if [ -n "$a" ] && [ "$a" = "$b" ]; then
      warn "destination $DEST is on the same filesystem as the live state ($a) — that is not off-host. RAID is not a backup."
    fi
  fi
}

# ---------- snapshot ----------

# Consistent online snapshot of a live SQLite DB + proof it is readable.
#
# hopboxd's DBs are rollback-journal (not WAL), so a writer holds an EXCLUSIVE lock
# while it commits and a snapshot taken right then gets SQLITE_BUSY — measured at
# ~15% of attempts under a write-hammering daemon. So: a busy timeout, and retries
# on top of it. The sqlite3 CLI can also report an error on stderr, so treat any
# output as failure, not just a non-zero exit.
BUSY_MS="${HOPBOX_BACKUP_BUSY_MS:-30000}"
SNAP_TRIES="${HOPBOX_BACKUP_TRIES:-3}"

snapshot_db() { # src dst → prints the integrity_check result
  local src=$1 dst=$2 q out res try objs_src objs_dst
  q=${dst//\'/\'\'}
  for try in $(seq 1 "$SNAP_TRIES"); do
    rm -f "$dst"
    # VACUUM INTO: an online, consistent copy of a live DB (never a file copy).
    out=$(sqlite3 "$src" "PRAGMA busy_timeout=$BUSY_MS; VACUUM INTO '$q'" 2>&1 | grep -v "^$BUSY_MS\$") || true
    [ -z "$out" ] && [ -s "$dst" ] && break
    # sqlite < 3.27 has no VACUUM INTO — fall back to the online backup API.
    rm -f "$dst"
    out=$(sqlite3 -cmd ".timeout $BUSY_MS" "$src" ".backup '$q'" 2>&1) || true
    [ -z "$out" ] && [ -s "$dst" ] && break
    [ "$try" = "$SNAP_TRIES" ] && die "snapshot of $src failed after $SNAP_TRIES tries: ${out:-empty output file}"
    warn "snapshot of $src busy (try $try/$SNAP_TRIES): $out"
    sleep $((try * 2))
  done
  chmod 600 "$dst"
  # A snapshot is only a backup once it has proved itself readable and complete.
  res=$(sqlite3 "$dst" 'PRAGMA integrity_check;' | head -1)
  [ "$res" = ok ] || die "integrity_check failed on the snapshot of $src: $res"
  objs_dst=$(sqlite3 "$dst" 'SELECT count(*) FROM sqlite_master;')
  [ "$objs_dst" -gt 0 ] || die "snapshot of $src has no schema — refusing to ship an empty backup"
  # Compare against the source's schema too (a truncated copy can still pass
  # integrity_check). If the source is busy right now, skip the comparison rather
  # than fail a snapshot that already proved itself intact.
  objs_src=$(sqlite3 "$src" "PRAGMA busy_timeout=$BUSY_MS; SELECT count(*) FROM sqlite_master;" 2>/dev/null | tail -1)
  case "$objs_src" in
    ''|*[!0-9]*) warn "could not read the schema count of $src (busy) — snapshot verified on its own" ;;
    *) [ "$objs_src" = "$objs_dst" ] || die "snapshot of $src is missing schema objects ($objs_dst of $objs_src)" ;;
  esac
  echo "$res"
}

cmd_run() {
  need sqlite3 "SQLite snapshots"
  need tar
  dest_require
  dest_offhost_check

  [ -f "$DB" ] || die "box database not found: $DB (set HOPBOX_BACKUP_DB or db: in $HOPBOXD_CONFIG)"
  [ -f "$HOST_KEY" ] || die "SSH host key not found: $HOST_KEY — refusing to call this a backup"

  local ts stem work stage archive manifest
  ts=$(stamp_now)
  stem="$PREFIX_NAME$ts"
  mkdir -p "$LOCAL_DIR"; chmod 700 "$LOCAL_DIR"
  work=$(mktemp -d "$LOCAL_DIR/.stage.XXXXXX")
  # shellcheck disable=SC2064  # $work is fixed at trap time on purpose
  trap "rm -rf '$work'" EXIT
  stage="$work/$stem"; mkdir -p "$stage"; chmod 700 "$stage"
  manifest="$stage/MANIFEST"

  {
    echo "hopbox state backup"
    echo "name:      $NAME"
    echo "created:   $ts"
    echo "host:      $(hostname 2>/dev/null || echo unknown) ($(uname -srm))"
    echo "hopboxd:   $(cat /var/lib/hopbox/deployed-sha 2>/dev/null || echo unknown)"
    echo "source-db: $DB"
    echo "source-host-key: $HOST_KEY"
    echo
    echo "files (sha256  bytes  name  notes):"
  } >"$manifest"

  add_file() { # src name notes...
    local src=$1 name=$2; shift 2
    install -m600 "$src" "$stage/$name"
    printf '  %s  %s  %s  %s\n' "$(sha256_of "$stage/$name")" "$(size_of "$stage/$name")" "$name" "$*" >>"$manifest"
  }

  log "snapshotting SQLite state (VACUUM INTO + integrity_check)"
  local res
  res=$(snapshot_db "$DB" "$stage/hopboxd.db")
  printf '  %s  %s  %s  %s\n' "$(sha256_of "$stage/hopboxd.db")" "$(size_of "$stage/hopboxd.db")" "hopboxd.db" "integrity_check=$res from $DB" >>"$manifest"
  local d n
  for d in "$ACCOUNTS_DB" "$SHARES_DB"; do
    n=${d##*/}
    if [ -f "$d" ]; then
      res=$(snapshot_db "$d" "$stage/$n")
      printf '  %s  %s  %s  %s\n' "$(sha256_of "$stage/$n")" "$(size_of "$stage/$n")" "$n" "integrity_check=$res from $d" >>"$manifest"
    else
      warn "$d not present — skipping (the daemon creates it on first use)"
      echo "  -  -  $n  MISSING at backup time ($d)" >>"$manifest"
    fi
  done

  log "collecting the SSH host key (front-door identity)"
  add_file "$HOST_KEY" ssh-host-key "front-door host key — PRIVATE"
  [ -f "$HOST_KEY.pub" ] && add_file "$HOST_KEY.pub" ssh-host-key.pub "public half"
  if command -v ssh-keygen >/dev/null 2>&1; then
    echo "host-key-fingerprint: $(ssh-keygen -lf "$stage/ssh-host-key" 2>/dev/null | awk '{print $2}')" >>"$manifest"
  fi
  if [ "$INCLUDE_CONFIG" = true ] && [ -f "$HOPBOXD_CONFIG" ]; then
    add_file "$HOPBOXD_CONFIG" "hopboxd.yaml" "daemon config — MAY CONTAIN SECRETS"
  fi

  {
    echo
    echo "NOT in this archive: the shared workspace /wrk (MinIO bucket + its JuiceFS"
    echo "metadata), box disks and snapshots, and persistent homes. /wrk is scratch"
    echo "space, not durable storage. See $DOC_URL"
  } >>"$manifest"

  archive="$LOCAL_DIR/$stem.tar.gz"
  log "packing $stem.tar.gz"
  tar -C "$work" -czf "$archive" "$stem"
  chmod 600 "$archive"
  sha256_of "$archive" >"$archive.sha256"
  chmod 600 "$archive.sha256"

  log "shipping to $(dest_describe)"
  dest_put "$archive"
  dest_put "$archive.sha256"

  local bytes; bytes=$(size_of "$archive")   # before pruning may reclaim the local copy
  prune_dest
  prune_local

  log "backup complete: $stem.tar.gz ($bytes bytes) → $(dest_describe)"
  sed -n '/^files/,$p' "$manifest"
}

# ---------- retention ----------

prune_dest() {
  local cutoff names total i n s
  cutoff=$(stamp_days_ago "$KEEP_DAYS")
  names=$(dest_list)
  [ -n "$names" ] || return 0
  total=$(printf '%s\n' "$names" | wc -l | tr -d ' ')
  i=0
  while IFS= read -r n; do
    i=$((i + 1))
    [ $((total - i)) -lt "$KEEP_MIN" ] && break   # always keep the newest KEEP_MIN
    s=$(stamp_of "$n"); [ -n "$s" ] || continue
    if [ "$s" \< "$cutoff" ]; then
      log "prune $n (older than ${KEEP_DAYS}d)"
      dest_rm "$n"; dest_rm "$n.sha256"
    fi
  done <<EOF
$names
EOF
}

prune_local() { # local copies are a convenience, not the backup — keep a few
  local names total i n
  names=$(list_dir_archives "$LOCAL_DIR")
  [ -n "$names" ] || return 0
  total=$(printf '%s\n' "$names" | wc -l | tr -d ' ')
  i=0
  while IFS= read -r n; do
    i=$((i + 1))
    [ $((total - i)) -lt "$KEEP_LOCAL" ] && break
    rm -f "$LOCAL_DIR/$n" "$LOCAL_DIR/$n.sha256"
  done <<EOF
$names
EOF
}

# ---------- list / fetch / verify / restore ----------

cmd_list() {
  dest_require
  local names
  names=$(dest_list)
  if [ -z "$names" ]; then
    echo "no archives at $(dest_describe)"
    return 0
  fi
  printf '%s\n' "$names"
  echo
  echo "latest: $(printf '%s\n' "$names" | tail -1)   at $(dest_describe)"
}

resolve_archive() { # [latest|name] → name
  local want=${1:-latest} names
  if [ "$want" != latest ]; then echo "${want##*/}"; return 0; fi
  names=$(dest_list)
  [ -n "$names" ] || die "no archives at $(dest_describe)"
  printf '%s\n' "$names" | tail -1
}

# Fetch + unpack + prove every DB in it is intact. Prints the unpacked dir.
fetch_and_check() { # name into_dir → dir
  local name=$1 into=$2 tgz got want f res
  mkdir -p "$into"; chmod 700 "$into"
  tgz="$into/$name"
  dest_get "$name" "$tgz"
  if dest_get "$name.sha256" "$tgz.sha256" 2>/dev/null; then
    want=$(awk '{print $1}' "$tgz.sha256"); got=$(sha256_of "$tgz")
    [ "$want" = "$got" ] || die "checksum mismatch for $name (want $want, got $got)"
    echo "  checksum: ok" >&2
  else
    warn "no .sha256 sidecar for $name — transfer integrity unverified"
  fi
  tar -C "$into" -xzf "$tgz"
  local dir="$into/${name%.tar.gz}"
  [ -d "$dir" ] || die "archive $name did not contain ${name%.tar.gz}/"
  chmod 700 "$dir"; chmod 600 "$dir"/* 2>/dev/null || true
  for f in "$dir"/*.db; do
    [ -f "$f" ] || continue
    res=$(sqlite3 "$f" 'PRAGMA integrity_check;' | head -1)
    [ "$res" = ok ] || die "restored ${f##*/} FAILS integrity_check: $res"
    echo "  ${f##*/}: integrity_check=ok" >&2
  done
  [ -f "$dir/ssh-host-key" ] || die "archive has no ssh-host-key"
  if command -v ssh-keygen >/dev/null 2>&1; then
    ssh-keygen -lf "$dir/ssh-host-key" >/dev/null 2>&1 || die "ssh-host-key in $name is not a usable key"
    echo "  ssh-host-key: $(ssh-keygen -lf "$dir/ssh-host-key" | awk '{print $2}')" >&2
  fi
  echo "$dir"
}

cmd_verify() { # prove the newest (or a named) archive would restore — then throw it away
  need sqlite3; dest_require
  local name tmp dir
  name=$(resolve_archive "${1:-latest}")
  tmp=$(mktemp -d "${TMPDIR:-/tmp}/hopbox-verify.XXXXXX")
  # shellcheck disable=SC2064
  trap "rm -rf '$tmp'" EXIT
  log "verifying $name from $(dest_describe)"
  dir=$(fetch_and_check "$name" "$tmp")
  echo
  sed -n '/^files/,$p' "$dir/MANIFEST" 2>/dev/null || true
  echo
  log "$name is restorable (all DBs pass integrity_check, host key parses)"
}

cmd_restore() {
  need sqlite3; dest_require
  local want=latest into="" apply=false
  while [ $# -gt 0 ]; do
    case "$1" in
      --into) into=${2:?--into needs a directory}; shift 2 ;;
      --apply) apply=true; shift ;;
      -*) die "unknown flag $1" ;;
      *) want=$1; shift ;;
    esac
  done
  local name dir
  name=$(resolve_archive "$want")
  [ -n "$into" ] || into="$LOCAL_DIR/restore-$(stamp_now)"
  log "fetching $name from $(dest_describe) → $into"
  dir=$(fetch_and_check "$name" "$into")
  log "staged and verified: $dir"

  if [ "$apply" != true ]; then
    cat <<TXT

Nothing has been changed on this host. To install this snapshot over the live state:

  hopbox-backup restore $name --apply

or do it by hand (hopboxd MUST be stopped — a running daemon holds the DBs open):

  systemctl stop ${SERVICE:-hopboxd}
  install -m600 $dir/hopboxd.db          $DB
  install -m600 $dir/hopboxd-accounts.db $ACCOUNTS_DB
  install -m600 $dir/hopboxd-shares.db   $SHARES_DB
  rm -f $DB-wal $DB-shm $ACCOUNTS_DB-wal $ACCOUNTS_DB-shm $SHARES_DB-wal $SHARES_DB-shm
  install -m600 $dir/ssh-host-key        $HOST_KEY
  systemctl start ${SERVICE:-hopboxd}
TXT
    return 0
  fi

  # --- apply: stop the daemon, keep the old state, swap in the snapshot ---
  if [ -n "$SERVICE" ] && command -v systemctl >/dev/null 2>&1; then
    log "stopping $SERVICE"
    systemctl stop "$SERVICE"
  else
    warn "no service manager configured (HOPBOX_BACKUP_SERVICE empty) — you must have stopped hopboxd yourself"
  fi
  if [ "${HOPBOX_BACKUP_ALLOW_RUNNING:-}" != 1 ] &&
     command -v pgrep >/dev/null 2>&1 && pgrep -x hopboxd >/dev/null 2>&1; then
    die "hopboxd is still running — restoring under a live daemon would corrupt the DBs.
  Stop it and retry. If that process is a *different* daemon (not the one owning $DB),
  re-run with HOPBOX_BACKUP_ALLOW_RUNNING=1."
  fi

  local aside
  aside="$LOCAL_DIR/pre-restore-$(stamp_now)"
  mkdir -p "$aside"; chmod 700 "$aside"
  log "keeping the current state in $aside (nothing is deleted)"
  local f
  for f in "$DB" "$ACCOUNTS_DB" "$SHARES_DB" "$HOST_KEY"; do
    [ -f "$f" ] && install -m600 "$f" "$aside/${f##*/}"
  done

  install_one() { # staged-name live-path
    [ -f "$dir/$1" ] || { warn "$1 not in the archive — leaving $2 as it is"; return 0; }
    install -m600 "$dir/$1" "$2"
    # A stale WAL/SHM from the *old* database must not be replayed onto the new one.
    rm -f "$2-wal" "$2-shm"
    log "restored ${2}"
  }
  install_one hopboxd.db "$DB"
  install_one hopboxd-accounts.db "$ACCOUNTS_DB"
  install_one hopboxd-shares.db "$SHARES_DB"
  install_one ssh-host-key "$HOST_KEY"
  [ -f "$dir/ssh-host-key.pub" ] && install -m644 "$dir/ssh-host-key.pub" "$HOST_KEY.pub"

  if [ -n "$SERVICE" ] && command -v systemctl >/dev/null 2>&1; then
    log "starting $SERVICE"
    systemctl start "$SERVICE"
    sleep 2
    log "$SERVICE: $(systemctl is-active "$SERVICE")"
  fi
  if command -v ssh-keygen >/dev/null 2>&1; then
    log "front-door host key is now $(ssh-keygen -lf "$HOST_KEY" | awk '{print $2}') — clients see no host-key change if this matches the old one"
  fi
  cat <<TXT

Restored from $name. Connected SSH sessions were dropped when the daemon stopped;
clients reconnect and — because the host key came back with the state — see no
host-key warning. Boxes created after $(stamp_of "$name") are not in this snapshot.
Previous state kept at $aside.

The daemon config in the archive was NOT installed (it may not match this host).
If this is a rebuilt server, compare it: $dir/hopboxd.yaml vs $HOPBOXD_CONFIG
TXT
}

usage() {
  cat >&2 <<TXT
hopbox-backup — verified, off-host backups of hopboxd state

  hopbox-backup run                       snapshot + verify + ship + prune
  hopbox-backup list                      archives on the destination
  hopbox-backup verify [latest|ARCHIVE]   fetch one and prove it restores
  hopbox-backup restore [latest|ARCHIVE] [--into DIR] [--apply]

Config: $CONF_FILE   Docs: $DOC_URL
TXT
}

case "${1:-run}" in
  run) shift || true; cmd_run ;;
  list) shift || true; cmd_list ;;
  verify) shift || true; cmd_verify "$@" ;;
  restore) shift || true; cmd_restore "$@" ;;
  -h|--help|help) usage ;;
  *) usage; exit 2 ;;
esac
